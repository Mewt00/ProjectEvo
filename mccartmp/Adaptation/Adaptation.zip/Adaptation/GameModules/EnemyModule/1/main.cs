//-----------------------------------------------------------------------------
// PlayerModule: EnemyUnit class and functions
//-----------------------------------------------------------------------------

function EnemyModule::create( %this )
{
    exec("./scripts/EnemyUnit.cs");
}

//-----------------------------------------------------------------------------

function EnemyModule::destroy( %this )
{
}
