//-----------------------------------------------------------------------------
// PlayerModule: EnemyUnit class and functions
//-----------------------------------------------------------------------------

function EnemyUnit::onAdd( %this )
{
	%this.initialize();
}

//-----------------------------------------------------------------------------

function EnemyUnit::initialize(%this)
{
	exec("./ToolNode.cs");
	%this.setSceneGroup(10);		//Enemy Unit sceneGroup

	%this.health = 100;
	
	%this.setAngle(90);
	
	//%this.setupSprite();
	%this.setupBehaviors();

	%this.setSceneLayer(10);
	
    %this.createPolygonBoxCollisionShape(74, 78);
    %this.setCollisionShapeIsSensor(0, true);
    %this.setCollisionGroups( "5 15" );
	//%this.CollisionCallback = true;
	%this.setCollisionCallback(true);
	
	//echo(%this.getCollisionShapeArea(0));
					
	%this.configureTools("0 0 0 0 0 1 3");		// ordering: shield/parry/acid/tar/blade/shooter/blob
}

//-----------------------------------------------------------------------------

function EnemyUnit::setupSprite( %this )
{
	%this.addSprite("0 0");
	%this.setSpriteImage("GameAssets:basicenemy", 0);
	%this.setSpriteSize(74, 78);
}

//-----------------------------------------------------------------------------

function EnemyUnit::setupBehaviors( %this )
{
	exec("./behaviors/movement/Drift.cs");
	exec("./behaviors/ai/faceObject.cs");
	%driftMove = DriftBehavior.createInstance();
	%driftMove.minSpeed = 300;
	%driftMove.maxSpeed = 350;
	%this.addBehavior(%driftMove);
	
	%faceObj = FaceObjectBehavior.createInstance();
	%faceObj.object = mainPlayer;
	%faceObj.rotationOffset = 180;
	%this.addBehavior(%faceObj);
}

//-----------------------------------------------------------------------------
///ordering: shield/parry/acid/tar/blade/shooter/blob

function EnemyUnit::configureTools(%this, %chromosome)
{
	%this.toolShield_count = getWord(%chromosome, 0);
	%this.toolParry_count = getWord(%chromosome, 1);
	%this.toolAcid_count = getWord(%chromosome, 2);
	%this.toolTar_count = getWord(%chromosome, 3);
	%this.toolBlade_count = getWord(%chromosome, 4);
	%this.toolShooter_count = getWord(%chromosome, 5);
	%this.toolBlob_count = getWord(%chromosome, 6);
	
	%this.bodyIndexer = 0;
	
	%this.myBodyContainer = new SimSet();
	
	%this.myBodyContainer.add(%this.addToolNode("Blob", "0 0"));	//0,0 is always first Blob node
	%this.bodyIndexer++;
	
	for(%i = 1; %i < %this.toolBlob_count; %i++) 		
	{
		%nextPosition = %this.findViablePosition(%this.myBodyContainer.getObject(%this.bodyIndexer - 1).getOpenSlots(), true);
		
		%this.myBodyContainer.add(%this.addToolNode("Blob", %nextPosition));
		%this.bodyIndexer++;
	}
	%nextPosition = "";
	
	for(%i = 0; %i < %this.toolShooter_count; %i++) 		
	{
		%allPositions = "";
		%counter = 0;
		for(%j = 0; %j < %this.myBodyContainer.getCount(); %j++)
		{
			%allPositions = %allPositions @ %this.myBodyContainer.getObject(%j).getOpenSlots() @ " ";
			%counter++;
		}
		
		//echo(%allPositions);
		
		%nextPosition = %this.findViablePosition(%allPositions, true);
		
		//echo(%nextPosition);
		
		%this.myBodyContainer.add(%this.addToolNode("Shooter", %nextPosition));
		%this.bodyIndexer++;
	}
	
	/*
	%this.myBody[0] = %this.createToolNode("Shooter", 0, 2);
	%this.myBody[0] = %this.createToolNode("Blob", 0, 0);
	%this.myBody[0] = %this.addToolNode("Blob", 1, 1);
	%this.myBody[0] = %this.addToolNode("Blob", -1, 1);
	%this.myBody[0] = %this.addToolNode("Blob", 0, 1);
	*/
}

//-----------------------------------------------------------------------------
///call this to add tools to body. ensures toolNode is tracked in grid

function EnemyUnit::addToolNode( %this, %type, %position)
{
	%tool = %this.createToolNode(%type, getWord(%position, 0), getWord(%position, 1));
	%this.addToGrid(%tool);
	return %tool;
}

//-----------------------------------------------------------------------------

function EnemyUnit::addToGrid( %this, %tool)
{
	%this.myBody[%tool.bodyPosX, %tool.bodyPosY] = %tool;
}

//-----------------------------------------------------------------------------
///should only be called through addToolNode(...)

function EnemyUnit::createToolNode( %this, %type, %posX, %posY)
{
	%nextTool = new SceneObject()
	{
		class = "ToolNode";
		owner = %this;
		toolType = %type;
		bodyPosX = %posX;
		bodyPosY = %posY;
		orientation = %this.findToolOrientation(%posX, %posY);
	};
	
	return %nextTool;
}

//-----------------------------------------------------------------------------

function EnemyUnit::findToolOrientation( %this, %posX, %posY)
{
	echo(%posX SPC %posY);
	if(isObject(%this.myBody[%posX, %posY - 1]))		//down
	{
		if(%this.myBody[%posX, %posY - 1].toolType $= "Blob")
			return 0;
	}
	if(isObject(%this.myBody[%posX + 1, %posY]))		//right
	{
		if(%this.myBody[%posX + 1, %posY].toolType $= "Blob")
			return 90;
	}
	if(isObject(%this.myBody[%posX, %posY + 1]))		//up
	{
		if(%this.myBody[%posX, %posY + 1].toolType $= "Blob")
			return 180;
	}
	if(isObject(%this.myBody[%posX - 1, %posY]))		//left
	{
		if(%this.myBody[%posX - 1, %posY].toolType $= "Blob")
			return 270;
	}
	return 0;
}

//-----------------------------------------------------------------------------
///finds free body coordinate to add toolNode to

function EnemyUnit::findViablePosition( %this, %positions , %flag)			
{
	for(%i = 0; %i < getWordCount(%positions) - 1; %i += 2)
	{
		%currPosition = getWord(%positions, %i) SPC getWord(%positions, %i + 1);
		
		if(!isObject(%this.myBody[getWord(%currPosition, 0), getWord(%currPosition, 1)]))
		{
			return %currPosition;
		}
	}
	
	return "0 0";		// "0 0" reserved for first Blob tool node added, so this means no viable positions found
}

//-----------------------------------------------------------------------------
///concats and returns chromosome code

function EnemyUnit::getChromosome( %this )
{
	%chromosome = %this.toolShield_count SPC
	%this.toolParry_count SPC
	%this.toolAcid_count SPC
	%this.toolTar_count SPC
	%this.toolBlade_count SPC
	%this.toolShooter_count SPC
	%this.toolBlob_count;
	
	return %chromosome;
}

//-----------------------------------------------------------------------------

function EnemyUnit::destroy( %this )
{
}
