//-----------------------------------------------------------------------------
// PlayerModule: EnemyUnit class and functions
//-----------------------------------------------------------------------------

function ToolNode::onAdd( %this )
{
	%this.initialize();
}

//-----------------------------------------------------------------------------

function ToolNode::initialize(%this)
{	
	%this.setSceneGroup(10);		//Enemy Unit sceneGroup

	%this.myWidth = 64;
	%this.myHeight = 64;
	
	%this.setupSprites();
	
	%this.setupBehaviors();
	%this.setupCollisionShape();

    //%this.createPolygonBoxCollisionShape(74, 78);
    //%this.setCollisionShapeIsSensor(0, true);
    //%this.setCollisionGroups( "5 15" );
	//%this.CollisionCallback = true;
	%this.setCollisionCallback(false);
	
}

//-----------------------------------------------------------------------------

function ToolNode::setupCollisionShape( %this )
{
	%shapePoints = %this.bodyPosX*%this.myWidth SPC %this.bodyPosY*%this.myHeight 
		SPC (%this.bodyPosX + 1)*%this.myWidth SPC bodyPosY*%this.myHeight 
		SPC (%this.bodyPosX + 1)*%this.myWidth SPC (bodyPosY + 1)*%this.myHeight
		SPC %this.bodyPosX*%this.myWidth SPC (bodyPosY + 1)*%this.myHeight;
	%this.owner.createPolygonCollisionShape(%shapePoints);
}

//-----------------------------------------------------------------------------

function ToolNode::setupSprites( %this )
{
	echo(%this.getId() SPC %this.bodyPosX*%this.myWidth SPC %this.bodyPosY*%this.myHeight);
	
	%this.owner.addSprite(%this.bodyPosX*%this.myWidth SPC %this.bodyPosY*%this.myHeight);
	
	//switch...case
	if(%this.toolType $= "Blob") {
		%this.setupSpriteBlob();
	}
	else {
		%this.setupSpriteShooter();
	}
	
	%this.owner.setSpriteAngle(%this.orientation);
}
//-----------------------------------------------------------------------------

function ToolNode::setupSpriteBlob( %this )
{
	%this.owner.setSpriteImage("GameAssets:tool_body1x1_a", 0);
	%this.owner.setSpriteSize(88, 88);
	%this.owner.setSpriteRenderGroup(10);
}

//-----------------------------------------------------------------------------

function ToolNode::setupSpriteShooter( %this )
{
	%this.owner.setSpriteImage("GameAssets:tool_shooter_a", 0);
	%this.owner.setSpriteSize(64, 64);
	%this.owner.setSpriteRenderGroup(3);
}

//-----------------------------------------------------------------------------

function ToolNode::setupBehaviors( %this )
{
	exec("./behaviors/movement/Drift.cs");
	%driftMove = DriftBehavior.createInstance();
	%this.addBehavior(%driftMove);
}

//-----------------------------------------------------------------------------

function ToolNode::getOpenSlots( %this )
{
	if(%this.toolType !$= "Blob")
		return "";
		
		
	%down = (%this.bodyPosX) SPC (%this.bodyPosY - 1);
	%right = (%this.bodyPosX + 1) SPC (%this.bodyPosY);
	%up = (%this.bodyPosX) SPC (%this.bodyPosY + 1);
	%left = (%this.bodyPosX - 1) SPC (%this.bodyPosY);
	
	return %down SPC %right SPC %up SPC %left;
}
//-----------------------------------------------------------------------------

function ToolNode::getBodyPosistion( %this )
{
	return (%this.bodyPosX) SPC (%this.bodyPosY);
}

//-----------------------------------------------------------------------------

function ToolNode::destroy( %this )
{
}
