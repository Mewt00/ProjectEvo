//-----------------------------------------------------------------------------
// PlayerModule: player class and functions
//-----------------------------------------------------------------------------

function PlayerModule::create( %this )
{
    exec("./scripts/Player.cs");
}

//-----------------------------------------------------------------------------

function PlayerModule::destroy( %this )
{
}
