fishTutorialBase is the starting point for the Fish Tutorial

See the tutorial for how to begin with this template.  It is most likely located at https://github.com/GarageGames/Torque2D/wiki.


